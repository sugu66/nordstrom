module.exports = {
  sections: {
	selectCategory:{
		selector: '#root',
			elements:{
					menLink:{
						selector : 'a[href="/category/Men"].primary-nav__link'
					}
				}
	}
  }
  };