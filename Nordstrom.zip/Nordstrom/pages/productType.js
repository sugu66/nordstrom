module.exports = {
  sections: {
	selectProductType:{
		selector: '.category-landing-page',
			elements:{
					tshirtsSubLink:{
						selector : '.menu_level_2 li a[href="/shop/Men/Clothing/Activewear"]',
											
					}
				}
	}
  }
};