module.exports = {
  sections: {
	product:
	{
		selector: 'body.catalog-page',
		elements:{
				selectTshirt : {
					selector : '.catalog-grid .catalog-grid-cell:first-child a'
				}
			}
	
  }
  }
  };